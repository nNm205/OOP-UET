public class Circle implements GeometricObject {
    public static final double PI = 3.14;
    private double radius;
    private Point center;

    /**
     * Circle():
     * khoi tao co tham so.
     */

    public Circle(Point center1, double radius1) {
        center = center1;
        radius = radius1;
    }

    /**
     * getCenter():
     * get center point.
     */

    public Point getCenter() {
        return center;
    }

    /**
     * setCenter():
     * set center.
     */

    public void setCenter(Point center1) {
        center = center1;
    }

    /**
     * getRadius():
     * get radius.
     */

    public double getRadius() {
        return radius;
    }

    /**
     * setRadius():
     * set radius.
     */

    public void setRadius(double radius1) {
        radius = radius1;
    }

    /**
     * getArea():
     * get area.
     */

    @Override
    public double getArea() {
        return PI * radius * radius;
    }

    /**
     * getPerimeter():
     * get perimeter.
     */

    @Override
    public double getPerimeter() {
        return 2.0 * PI * radius;
    }

    /**
     * toString():
     * to string.
     */

    @Override
    public String getInfo() {
        return "Circle[(" + String.format("%.2f", center.getPointX())
                + "," + String.format("%.2f", center.getPointY())
                + "),r=" + String.format("%.2f", radius)
                + "]";
    }
}
