public class Bishop extends Piece {
    /**
     * Bishop():
     * khoi tao co tham so.
     */

    public Bishop(int coordinatesX, int coordinatesY) {
        super(coordinatesX, coordinatesY);
    }

    /**
     * Bishop():
     * khoi tao co tham so.
     */

    public Bishop(int coordinatesX, int coordinatesY, String color) {
        super(coordinatesX, coordinatesY, color);
    }

    /**
     * getSymbol():
     * get symbol.
     */

    @Override
    public String getSymbol() {
        return "B";
    }

    /**
     * canMove():
     * can move.
     */

    @Override
    public boolean canMove(Board board, int newX, int newY) {
        if (!board.validate(newX, newY)) {
            return false;
        }
        if (Math.abs(getCoordinatesX() - newX) != Math.abs(getCoordinatesY() - newY)) {
            return false;
        }
        if (getCoordinatesX() < newX) {
            for (int curX = getCoordinatesX() + 1; curX < newX; curX++) {
                if (getCoordinatesY() < newY) {
                    for (int curY = getCoordinatesY() + 1; curY < newY; curY++) {
                        if (Math.abs(curX - getCoordinatesX())
                                == Math.abs(curY - getCoordinatesY())) {
                            if (board.getAt(curX, curY) != null) {
                                return false;
                            }
                        }
                    }
                } else {
                    for (int curY = getCoordinatesY() - 1; curY > newY; curY--) {
                        if (Math.abs(curX - getCoordinatesX())
                                == Math.abs(curY - getCoordinatesY())) {
                            if (board.getAt(curX, curY) != null) {
                                return false;
                            }
                        }
                    }
                }
            }
        } else {
            for (int curX = getCoordinatesX() - 1; curX > newX; curX--) {
                if (getCoordinatesY() < newY) {
                    for (int curY = getCoordinatesY() + 1; curY < newY; curY++) {
                        if (Math.abs(curX - getCoordinatesX())
                                == Math.abs(curY - getCoordinatesY())) {
                            if (board.getAt(curX, curY) != null) {
                                return false;
                            }
                        }
                    }
                } else {
                    for (int curY = getCoordinatesY() - 1; curY > newY; curY--) {
                        if (Math.abs(curX - getCoordinatesX())
                                == Math.abs(curY - getCoordinatesY())) {
                            if (board.getAt(curX, curY) != null) {
                                return false;
                            }
                        }
                    }
                }
            }
        }
        Piece curPiece = board.getAt(newX, newY);
        if (curPiece != null && curPiece.getColor() == getColor()) {
            return false;
        } else {
            return true;
        }
    }
}
