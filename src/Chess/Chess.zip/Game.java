import java.util.ArrayList;

public class Game {
    private Board board;
    private ArrayList<Move> moveHistory = new ArrayList<>();

    /**
     * Game():
     * khoi tao co tham so.
     */

    public Game(Board board) {
        this.board = board;
    }

    /**
     * movePiece():
     * move piece.
     */

    public void movePiece(Piece piece, int x, int y) {
        if (piece.canMove(board, x, y)) {
            Piece curPiece = board.getAt(x, y);
            Move newMove = new Move(piece.getCoordinatesX(),
                    piece.getCoordinatesY(), x, y, piece);
            board.removeAt(piece.getCoordinatesX(), piece.getCoordinatesY());
            if (curPiece != null) {
                newMove.setKilledPiece(curPiece);
                board.removeAt(x, y);
            }
            piece.setCoordinatesX(x);
            piece.setCoordinatesY(y);
            board.addPiece(piece);
            moveHistory.add(newMove);
        }
    }

    /**
     * getBoard():
     * get board.
     */

    public Board getBoard() {
        return board;
    }

    /**
     * setBoard():
     * set board.
     */

    public void setBoard(Board board) {
        this.board = board;
    }

    /**
     * getMoveHistory():
     * get moveHistory.
     */

    public ArrayList<Move> getMoveHistory() {
        return moveHistory;
    }
}
  