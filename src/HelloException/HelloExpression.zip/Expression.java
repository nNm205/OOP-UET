public abstract class Expression {
    /**
     * toString():
     * to string.
     */

    public abstract String toString();

    /**
     * evaluate():
     * evaluate.
     */

    public abstract double evaluate();
}
